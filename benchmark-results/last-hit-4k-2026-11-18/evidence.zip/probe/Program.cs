using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using DotaCoach.Desktop;
using DotaCoach.TwoPc;

internal static class Perf {
    public static long Now=>Stopwatch.GetTimestamp(); public static double Ms(long ticks)=>ticks*1000d/Stopwatch.Frequency;
    public static long UiStamp; public static volatile string Phase="warm"; public static readonly List<object> Output=[];
    private static readonly List<(string p,long start,long got,long read,long done,int bars,int marks,int prep,int wait,int finish,int deny,int sw,int sh,int w,int h)> frames=[];
    private static readonly List<(string p,long stamp,long rendered)> renders=[];
    private static readonly List<(string p,bool ok)> polls=[];
    public static void Poll(bool ok)=>polls.Add((Phase,ok));
    public static void Frame(long start,long got,long read,long done,int bars,List<DrillMark> marks,GameSurface g,int w,int h){int p=0,t=0,f=0,d=0;foreach(var m in marks)switch(m.Plan.Action){case HitAction.Prepare:p++;break;case HitAction.Wait:t++;break;case HitAction.Finish:f++;break;case HitAction.Deny:d++;break;};frames.Add((Phase,start,got,read,done,bars,marks.Count,p,t,f,d,g.Width,g.Height,w,h));}
    public static void Render(long stamp)=>renders.Add((Phase,stamp,Now));
    public static void Save(string dir){File.WriteAllLines(Path.Combine(dir,"frames.csv"),new[]{"phase,startQpc,grabMs,scanMs,planMs,totalMs,bars,marks,prepare,wait,finish,deny,sourceW,sourceH,readW,readH"}.Concat(frames.Select(x=>FormattableString.Invariant($"{x.p},{x.start},{Ms(x.got-x.start):F5},{Ms(x.read-x.got):F5},{Ms(x.done-x.read):F5},{Ms(x.done-x.start):F5},{x.bars},{x.marks},{x.prep},{x.wait},{x.finish},{x.deny},{x.sw},{x.sh},{x.w},{x.h}"))));File.WriteAllLines(Path.Combine(dir,"renders.csv"),new[]{"phase,startQpc,pollToWpfOnRenderMs"}.Concat(renders.Select(x=>FormattableString.Invariant($"{x.p},{x.stamp},{Ms(x.rendered-x.stamp):F5}")))); File.WriteAllText(Path.Combine(dir,"phases.json"),JsonSerializer.Serialize(new{frequency=Stopwatch.Frequency,logical=Environment.ProcessorCount,phases=Output,polls=polls.GroupBy(x=>x.p).Select(x=>new{phase=x.Key,total=x.Count(),empty=x.Count(y=>!y.ok)})},new JsonSerializerOptions{WriteIndented=true}));}
}
internal static class Program {
    [STAThread] static int Main(string[] args){if(args[0]=="checks"){int c=0;LastHitTests.Run((ok,s)=>{if(!ok)throw new Exception(s); c++;Console.WriteLine("PASS "+s);});Console.WriteLine($"{c} last-hit checks passed");return 0;}
        var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};app.Startup+=async(_,_)=>{try{await Run(args);app.Shutdown(0);}catch(Exception ex){Console.Error.WriteLine(ex);app.Shutdown(1);}};return app.Run();}
    private static async Task Run(string[] args){var dir=Path.GetFullPath(args[0]);Directory.CreateDirectory(dir); string log=args[1]; long offset=File.Exists(log)?new FileInfo(log).Length:0; string state=GsiSetup.StateDirectoryFor("Game");if(!File.Exists(Path.Combine(state,"gsi-identity.dpapi")))throw new Exception("Existing game-side GSI identity required"); await using var rx=await GsiReceiver.Start(resumeToken:GsiSetup.Token(state));
        LastHitPractice? drill=null; string phase="",status="idle"; int eligible=0,fg=0,n=0; long start=0,alloc=0; TimeSpan cpu=default; long ws=0,peakWs=0; var proc=Process.GetCurrentProcess(); var clock=Stopwatch.StartNew(); double debug=-10; var reader=(StreamReader?)null; string[] phases=["OFF1","ON1","ON2","OFF2"];int autoStep=-1;long autoAt=0; var label=new System.Windows.Controls.TextBlock(); bool auto=false; double gClock=0;
        async Task Arm(string p){Perf.Phase="warm";phase="";if(p.StartsWith("ON") && drill==null)drill=new LastHitPractice(()=>rx.CanPractice,.53,s=>{status=s;label.Text=s;});if(!p.StartsWith("ON")&&drill!=null){await drill.DisposeAsync();drill=null;status="off";} Console.WriteLine("arm "+p);}
        void Sample(string p){phase=p;eligible=fg=n=0;proc.Refresh();ws=peakWs=proc.WorkingSet64;alloc=GC.GetTotalAllocatedBytes();cpu=proc.TotalProcessorTime;gClock=rx.Latest().Player?.Clock??-1;start=Perf.Now;Perf.Phase=p;Console.WriteLine("sampling "+p);}
        void End(string p){if(phase!=p)return;Perf.Phase="warm";var stop=Perf.Now;proc.Refresh();double sec=Perf.Ms(stop-start)/1000;var cpuSec=(proc.TotalProcessorTime-cpu).TotalSeconds;Perf.Output.Add(new{phase=p,startQpc=start,endQpc=stop,sec,cpuMachinePct=cpuSec/sec*100/Environment.ProcessorCount,wsStartMiB=ws/1048576d,wsEndMiB=proc.WorkingSet64/1048576d,wsPeakSampledMiB=peakWs/1048576d,allocatedMiBPerSecond=(GC.GetTotalAllocatedBytes()-alloc)/1048576d/sec,samples=n,eligible,foreground=fg,gsiClockStart=gClock,gsiClockEnd=rx.Latest().Player?.Clock});phase="";Console.WriteLine("end "+p);}
        Console.WriteLine("READY");try{bool done=false;while(!done && clock.Elapsed.TotalMinutes<8 && !File.Exists(Path.Combine(dir,"stop"))){if(reader==null&&File.Exists(log)){var f=new FileStream(log,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete);if(f.Length>=offset)f.Seek(offset,SeekOrigin.Begin); reader=new StreamReader(f);}
                if(!auto && reader!=null){string? line;while((line=reader.ReadLine())!=null){int ix=line.IndexOf("LH26_",StringComparison.Ordinal);if(ix<0||line.Contains("echoln LH26_"))continue;string tag=line.Substring(ix).Trim();foreach(var p in phases){if(tag=="LH26_ARM_"+p)await Arm(p);if(tag=="LH26_SAMPLE_"+p)Sample(p);if(tag=="LH26_END_"+p)End(p);}if(tag=="LH26_DONE")done=true;}}
                if(!auto&&File.Exists(Path.Combine(dir,"auto"))){auto=true;autoStep=0;autoAt=Perf.Now;Console.WriteLine("autonomous phase clock; no engine fps alignment");}
                if(auto&&Perf.Now>=autoAt && (autoStep>0||rx.CanPractice&&GameWindow.Foreground()!=null)){int i=autoStep/3;if(i==phases.Length){done=true;}else{string p=phases[i];switch(autoStep%3){case 0:await Arm(p);autoAt=Perf.Now+5*Stopwatch.Frequency;break;case 1:Sample(p);autoAt=Perf.Now+25*Stopwatch.Frequency;break;case 2:End(p);autoAt=Perf.Now;break;}autoStep++;}}
                if(phase!=""){n++;if(rx.CanPractice)eligible++;if(GameWindow.Foreground()!=null)fg++;if(n%10==0){proc.Refresh(); peakWs=Math.Max(peakWs,proc.WorkingSet64);}}
                if(clock.Elapsed.TotalSeconds-debug>=5){debug=clock.Elapsed.TotalSeconds;var own=rx.Latest().Player;var g=GameWindow.Foreground();Console.WriteLine($"t={debug:F1} own={own?.Hero} xy={own?.X},{own?.Y} clock={own?.Clock} allowed={rx.CanPractice} foreground={g?.Width}x{g?.Height} diag={rx.LastDiagnostics?.Mode} status={status}");}await Task.Delay(80);}}
        finally{reader?.Dispose();if(phase!="")End(phase);if(drill!=null)await drill.DisposeAsync();Perf.Save(dir);} }
}

