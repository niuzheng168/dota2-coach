using System.Diagnostics;
using System.Globalization;
using System.Text.Json;
using DotaCoach.TwoPc;
// Replay only worker durations, not game images. No window, game access or system-wide timer change.
var trace=File.ReadLines(args[0]).Concat(File.ReadLines(args[1])).Where(x=>x.StartsWith("ON1,")).Select(x=>double.Parse(x.Split(',')[5],CultureInfo.InvariantCulture)).ToArray();
const int N=96;var work=Enumerable.Range(0,N).Select(i=>trace[(int)((long)i*trace.Length/N)]).ToArray();
using var precise=new PreciseTimer();using var stop=new CancellationTokenSource();var handle=stop.Token.WaitHandle; long hz=Stopwatch.Frequency;
object Run(string mode,int n){long[] edges=new long[n+1];var period=hz/25;long target=Stopwatch.GetTimestamp();for(int i=0;i<n;i++) {edges[i]=Stopwatch.GetTimestamp();long at=Environment.TickCount64;precise.Wait((long)(10000*work[i]));if(mode=="current"){handle.WaitOne((int)Math.Clamp(40-(Environment.TickCount64-at),1,40));}else{target+=period;long now=Stopwatch.GetTimestamp();if(now>target)target=now;else precise.Wait((target-now)*10000000/hz);}}edges[n]=Stopwatch.GetTimestamp();double[] gap=edges.Zip(edges.Skip(1),(a,b)=>(b-a)*1000.0/hz).Order().ToArray();return new{mode,n,effectiveHz=1000/gap.Average(),p50ms=gap[(int)Math.Ceiling(n*.50)-1],p95ms=gap[(int)Math.Ceiling(n*.95)-1],maxms=gap[^1]};}
Run("current",3);Run("absolute",3);var rounds=new[]{"current","absolute","absolute","current"}.Select(mode=>Run(mode,N)).ToArray();Console.WriteLine(JsonSerializer.Serialize(new{description="Normal-priority standalone timing test, same sampled work durations simulated by a waitable timer, no actual WGC/WPF or Dota input; not post-fix live-game performance.",samplesPerRound=N,meanSimulatedWorkerMs=work.Average(),rounds},new JsonSerializerOptions{WriteIndented=true}));
