using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
class Sample {
    [STAThread] static void Main(string[] args) {
        double Time(Action code) { long t=Stopwatch.GetTimestamp();code();return Stopwatch.GetElapsedTime(t).TotalMilliseconds; }
        var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};var win=new Window{WindowStyle=WindowStyle.None,ResizeMode=ResizeMode.NoResize,AllowsTransparency=true,Background=Brushes.Transparent,ShowInTaskbar=false,ShowActivated=false,IsHitTestVisible=false,Focusable=false};
        if(args.Length!=0){var prior=new Window{WindowStyle=WindowStyle.None,AllowsTransparency=true,ShowActivated=false,ShowInTaskbar=false};_ = new WindowInteropHelper(prior).EnsureHandle();var priorDpi=VisualTreeHelper.GetDpi(prior);var label=new FormattedText("本机练习：正补、反补、塔下垫刀",CultureInfo.CurrentUICulture,FlowDirection.LeftToRight,new Typeface("Microsoft YaHei UI"),15,Brushes.Gold,priorDpi.PixelsPerDip);var vis=new DrawingVisual();using(var dc=vis.RenderOpen()){_=label.Height;_=label.Width;dc.DrawText(label,new Point(0,0));} prior.Close();}
        var typeface=new Typeface("Microsoft YaHei UI");double handle=Time(()=>{_ = new WindowInteropHelper(win).EnsureHandle();}); if(win.IsVisible)throw new Exception("Window unexpectedly visible");
        var dpi=VisualTreeHelper.GetDpi(win);double em=80*.18*2/dpi.DpiScaleY;var timings=new List<object>();
        for(int i=0;i<5;i++){var v=new DrawingVisual();using var dc=v.RenderOpen();FormattedText? text=null;double construct=Time(()=>text=new FormattedText("正补",CultureInfo.CurrentUICulture,FlowDirection.LeftToRight,typeface,em,Brushes.Gold,dpi.PixelsPerDip));double measure=Time(()=>{_=text!.Height;_=text.Width;});double draw=Time(()=>dc.DrawText(text!,new Point(0,0)));timings.Add(new{construct,measure,draw,combined=construct+measure+draw});}
        win.Close(); app.Shutdown();Console.WriteLine(JsonSerializer.Serialize(new{dpi=dpi.PixelsPerDip,handle,draws=timings}));
    }
}
